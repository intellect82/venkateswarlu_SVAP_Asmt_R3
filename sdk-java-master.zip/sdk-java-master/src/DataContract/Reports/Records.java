package maxiPago.DataContract.Reports;

import java.util.List;

public class Records {

    private List<Record> record;

	public List<Record> getRecord() {
		return record;
	}   
    
	
}
