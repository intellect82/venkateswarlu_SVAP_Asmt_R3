package maxiPago.DataContract.Transactional;

public class SaveOnFileResponse {

	private String error;
    private String token;
    
	public String getError() {
		return error;
	}
	public String getToken() {
		return token;
	}
	
    
}
