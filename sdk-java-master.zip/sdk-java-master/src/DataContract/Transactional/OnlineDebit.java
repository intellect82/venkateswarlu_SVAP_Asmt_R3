package maxiPago.DataContract.Transactional;

public class OnlineDebit {
	
	private String parametersURL;
	
	public String getParametersUrl() {
		return parametersURL;
	}
	public void setParametersUrl(String parametersURL) {
		this.parametersURL = parametersURL;
	}
}
