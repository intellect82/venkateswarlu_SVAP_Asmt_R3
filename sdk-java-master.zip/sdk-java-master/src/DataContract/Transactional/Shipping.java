package maxiPago.DataContract.Transactional;


public class Shipping extends Address {

}
