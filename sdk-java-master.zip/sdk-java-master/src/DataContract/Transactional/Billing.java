package maxiPago.DataContract.Transactional;


public class Billing extends Address {

}
