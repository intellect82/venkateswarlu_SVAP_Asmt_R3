/usr/hdp/current/phoenix-client/bin/sqlline.py localhost:2181:/hbase-unsecure
