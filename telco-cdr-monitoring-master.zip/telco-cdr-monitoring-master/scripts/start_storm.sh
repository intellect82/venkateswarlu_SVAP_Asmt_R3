storm jar /root/telco-cdr-monitoring/target/telco-cdr-monitoring-1.0-SNAPSHOT.jar com.github.gbraccialli.telco.cdr.storm.Topology /root/telco-cdr-monitoring/conf/topology.props

