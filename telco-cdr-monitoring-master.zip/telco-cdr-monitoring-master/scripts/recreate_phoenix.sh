/usr/hdp/current/phoenix-client/bin/psql.py localhost:2181:/hbase-unsecure /root/cdr/phoenix/cdr.sql
