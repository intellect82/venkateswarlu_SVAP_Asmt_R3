./kafka_delete_topic.sh cdr
./restart_erase_solr.sh
./recreate_hive.sh
./recreate_phoenix.sh
