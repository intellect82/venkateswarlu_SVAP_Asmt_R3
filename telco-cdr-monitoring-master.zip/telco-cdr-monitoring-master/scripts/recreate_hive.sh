hive -f /root/cdr/hive/cdr.sql
